document.addEventListener('DOMContentLoaded', function() {
    // Event listener for signup form submission
    document.getElementById('signupForm').addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the form from submitting normally

        // Gather form data
        const formData = new FormData(this);
        const userData = {
            username: formData.get('username'),
            email: formData.get('email'),
            password: formData.get('password'),
            role: document.getElementById('role').value // Assuming 'role' is the id of the dropdown
        };

        // Make an AJAX request to submit the form data to the backend
        // Example using fetch API:
        fetch('/signup', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(userData)
        })
        .then(response => response.json())
        .then(data => {
            // Handle response from server
            console.log(data);
            // Redirect logic based on response (if needed)
        })
        .catch(error => {
            console.error('Error:', error);
        });
    });

    // Event listener for login form submission
    document.getElementById('loginForm').addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the form from submitting normally

        // Gather form data
        const formData = new FormData(this);
        const loginData = {
            email: formData.get('email'),
            password: formData.get('password'),
            role: document.getElementById('role').value // Assuming 'role' is the id of the dropdown
        };

        // Make an AJAX request to submit the form data to the backend
        // Example using fetch API:
        fetch('/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(loginData)
        })
        .then(response => response.json())
        .then(data => {
            // Handle response from server
            console.log(data);
            // Redirect logic based on response (if needed)
        })
        .catch(error => {
            console.error('Error:', error);
        });
    });
});
