const express = require('express');
const app = express();
const path = require('path');
const http = require('http');
const socketIo = require('socket.io');
const mongoose = require('mongoose');
const userRouter = require('./router/userRouter');
const Report = require('./model/reportModel');
const { getOperators } = require('./controller/supervisorController');
const { Socket } = require('dgram');
const { log } = require('console');
const server = http.createServer(app);
const io = socketIo(server);
const issueRouter = require('./router/issueRouter');
const logger = require('./middleware/logger');
const bodyParser = require('body-parser'); // Add this line


app.use(express.json());
app.use(bodyParser.json()); // Add this line
app.use('/api/reports', require('./router/reportRouter'));
app.use(logger);


io.on('connection', socket => {
  console.log('client connected');

  const reportChangeStream = Report.watch();
  reportChangeStream.on('change', change => {
    if (change.operationtype === 'insert' || change.operationtype === 'update' || change.operationtype === 'delete') {
      io.emit('reprotChange');
    }
  });

  socket.on('disconnect', () => {
    console.log('client disconnected');
  });
});


app.get('/socket.io/socket.io.js', (req, res) => {
  res.sendFile(__dirname + '/node_modules/socket.io-client/dist/socket.io.js');
});


// Middleware
app.use(express.json());

// Routes
app.use('/user', userRouter);
app.use('/api', getOperators);
app.use('/submit-issue', issueRouter); // Update this line


// Serve static files from the public directory
app.use(express.static(path.join(__dirname, 'public')));

// Serve HTML files from the views directory
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

app.get('/index', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

app.get('/contact', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'contact.html'));
});

app.get('/about', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'about.html'));
});

app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'login.html'));
});

app.get('/b', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'b.html'));
});


app.get('/signup', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'signup.html'));
});

app.get('/operator-dashboard', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'operator-dashboard.html'));
});

app.get('/supervisor-dashboard', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'supervisor-dashboard.html'));
});

app.get('/editoper', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'editoper.html'));
});

app.get('/editsuper', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'editsuper.html'));
});

app.get('/helpoper', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'helpoper.html'));
});

app.get('/helpsup', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'helpsup.html'));
});

app.get('/manualoper', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'manualoper.html'));
});

app.get('/Manualsup', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'Manualsup.html'));
});

app.get('/reportissueoper', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'reportissueoper.html'));
});

app.get('/report', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'report.html'));
});

app.get('/webcam', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'webcam.html'));
});

app.get('/safetyoper', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'safetyoper.html'));
});

app.get('/Safetyprecationssup', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'Safetyprecationssup.html'));
});

app.get('/trainingoper', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'trainingoper.html'));
});

app.get('/trainingsessionsup', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'trainingsessionsup.html'));
});

// Start the server
const PORT = process.env.PORT || 3000;

mongoose.connect("mongodb://localhost:27017/tablesaw")
  .then(
    app.listen(PORT, () => {
      console.log("Database Connected ")
      console.log(`Server is running on port ${PORT}`);
    })
)
.catch(e => { 
  console.log(e)
})