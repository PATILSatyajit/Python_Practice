const User = require('../model/userModel');

const loginController = async (req, res) => {
    try {
        const { username, password, role } = req.body;

        // Find user by username
        const user = await User.findOne({ username });

        // Check if user exists
        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }

        // Check if password matches
        if (password !== user.password) {
            return res.status(401).json({ message: "Incorrect password" });
        }

        // Check if selected role matches user's role
        if ((role === "Supervisor" && user.isSupervisor) || (role === "Operator" && !user.isSupervisor)) {
            return res.status(403).json({ message: "Role mismatch" });
        }

        // Redirect based on user role
        if (user.isSupervisor) {
            res.redirect('/supervisor-dashboard');
        } else {
            res.redirect('/operator-dashboard');
        }
    } catch (error) {
        console.error("Error:", error);
        res.status(500).json({ message: "Internal server error" });
    }
};

module.exports = loginController;
