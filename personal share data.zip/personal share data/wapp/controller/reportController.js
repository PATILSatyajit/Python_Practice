const Report = require('../model/reportModel');

exports.addReport = async (req, res) => {
  try {
    const { bladeguard, apron, rivingKnife, eyeglasses, pushstick, speedOfBlade, angleOfBlade, heightOfBlade } = req.body;
    const newReport = new Report({
      bladeguard,
      apron,
      rivingKnife,
      eyeglasses,
      pushstick,
      speedOfBlade,
      angleOfBlade,
      heightOfBlade
    });
    await newReport.save();
    res.status(201).send('Report added successfully');
  } catch (error) {
    console.error(error);
    res.status(500).send('Error adding report');
  }
};

