// routers/index.js

const express = require('express');
const router = express.Router();
const { getOperators } = require('../controller/supervisorController');

// Route to get non-supervisor users (operators)
router.get('/operators', supervisorController.getOperators);

module.exports = router;
